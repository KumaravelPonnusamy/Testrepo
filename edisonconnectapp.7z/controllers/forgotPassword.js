const User = require('../models/auth_user');
const mailer = require('../mailer/mailer');
const async = require('async');
const crypto = require('crypto');
const path = require('path');

exports.forgot_password = function(req, res) {
    async.waterfall([
      function(done) {
        User.findbyEmail({
          email: req.body.email
        },(err, res)=>{
          if (res) {
            done(err, res);
          } else {
            done('User not found.');
          }
        })
      },
      function(user, done) {
        // create the random token
        crypto.randomBytes(20, function(err, buffer) {
          var token = buffer.toString('hex');
          done(err, user, token);
        });
      },
      function(user, token, done) {
        User.findByIdAndUpdate( { id: user.id, reset_password_token: token, reset_password_expires: Date.now() + 86400000 },(err, new_user) => {
          done(err, token, new_user);
        });
      },
      function(token, user, done) {

        var data = {
          to: user.email_id,
          from: 'kumarapkvel@gmail.com',
          template: 'forgot-password-email',
          subject: 'Password help has arrived!',
          context: {
            url: 'http://localhost:3000/auth/reset_password?token=' + token,
            name: user.first_name
          }
        };
        
        smtpTransport.sendMail(data, function(err) {
          console.log('am in ',err)
          if (!err) {
            return res.json({ message: 'Kindly check your email for further instructions' });
          } else {
            return done(err);
          }
        });
      }
    ], function(err) {
      return res.status(422).json({ message: err });
    });
  };