'user strict';

const { db_read } = require('../config/db');

function findbyEmail(email, result){
    db_read.query("Select * from tbl_users where email_id = ?", email.email, function (err, res) {      
        if(err) {
            console.log("error: ", err);
            result(err, null);
        } else{
            result(null, res[0]);
        }
    });  
}
function findByIdAndUpdate(user, result) {
    console.log(user)
    const query = "UPDATE `tbl_users` SET `reset_password_expires` = '"+user.reset_password_token+"', `reset_password_token` = '"+user.reset_password_token+"' WHERE `id` = "+ user.id;
    db_read.query(query, function (err, res) {      
        console.log(res);
        if(err) {
            console.log("error: ", err);
            result(err, null);
        } else{
            db_read.query("Select * from tbl_users where id = ?", user.id, function (err, res) {      
                if(err) {
                    console.log("error: ", err);
                    result(err, null);
                } else{
                    result(null, res[0]);
                }
            });  
        }
    });  
}
module.exports = {findbyEmail, findByIdAndUpdate}