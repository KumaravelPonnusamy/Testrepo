import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-latest-orders',
  templateUrl: './latest-orders.component.html',
  styleUrls: ['./latest-orders.component.scss']
})
export class LatestOrdersComponent implements OnInit {

  constructor() { }
  public displayedColumns: string[] = ['orgId', 'name', 'status', 'date', 'total'];
  public data = [
    { orgId: 1, name: 'HG Hospital', status: 'On Going', date: 'H', total: 200, },
    { orgId: 2, name: 'PSG Hospital', status: 'Completed', date: 'He', total: 150, },
    { orgId: 3, name: 'LKG Hospital', status: 'Completed', date: 'Li', total: 100, },
    { orgId: 4, name: 'KMCH Hospital', status: 'Completed', date: 'Be', total: 250, },
    { orgId: 5, name: 'Kuppusamy Hospital', status: 'Completed', date: 'B', total: 263, },
    { orgId: 6, name: 'Ganga Hospital', status: 'Completed', date: 'C', total: 250, },
  ];
  ngOnInit(): void {
  }

}
