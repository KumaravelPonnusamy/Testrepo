import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-total-usage-brief',
  templateUrl: './total-usage-brief.component.html',
  styleUrls: ['./total-usage-brief.component.scss']
})
export class TotalUsageBriefComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
