import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TotalUsageBriefComponent } from './total-usage-brief.component';

describe('TotalUsageBriefComponent', () => {
  let component: TotalUsageBriefComponent;
  let fixture: ComponentFixture<TotalUsageBriefComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TotalUsageBriefComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TotalUsageBriefComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
