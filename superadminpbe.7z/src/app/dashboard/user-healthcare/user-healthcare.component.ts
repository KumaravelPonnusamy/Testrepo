import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-healthcare',
  templateUrl: './user-healthcare.component.html',
  styleUrls: ['./user-healthcare.component.scss']
})
export class UserHealthcareComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
