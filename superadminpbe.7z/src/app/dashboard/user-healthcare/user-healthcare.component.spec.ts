import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UserHealthcareComponent } from './user-healthcare.component';

describe('UserHealthcareComponent', () => {
  let component: UserHealthcareComponent;
  let fixture: ComponentFixture<UserHealthcareComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UserHealthcareComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UserHealthcareComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
