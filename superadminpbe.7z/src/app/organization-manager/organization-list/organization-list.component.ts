import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
@Component({
  selector: 'app-organization-list',
  templateUrl: './organization-list.component.html',
  styleUrls: ['./organization-list.component.scss']
})
export class OrganizationListComponent implements OnInit {

  constructor(private router: Router) { }
  public data = [
    {
      orgId: 1, name: 'HG Hospital', address: 'Coimbatore, TamilNadu, India', date: 'H', total: 200, clicked: false, isActive: true,
      admin_count: 4, caregiver_count: 40, patients_count: 120, gateway: 1, type: '', phone: '+1 112 11245 1212', email: 'sampleemail@sample.com'
    },
    {
      orgId: 2, name: 'PSG Hospital', address: 'Coimbatore, TamilNadu, India', date: 'He', total: 150, clicked: false, isActive: true,
      admin_count: 12, caregiver_count: 12, patients_count: 200, gateway: 26, type: '', phone: '+1 112 11245 1212', email: 'sampleemail@sample.com'
    },
    {
      orgId: 3, name: 'LKG Hospital', address: 'Coimbatore, TamilNadu, India', date: 'Li', total: 100, clicked: false, isActive: false,
      admin_count: 20, caregiver_count: 40, patients_count: 120, gateway: 25, type: '', phone: '+1 112 11245 1212', email: 'sampleemail@sample.com'
    },
    {
      orgId: 4, name: 'KMCH Hospital', address: 'Coimbatore, TamilNadu, India', date: 'Be', total: 250, clicked: false, isActive: true,
      admin_count: 7, caregiver_count: 40, patients_count: 220, gateway: 55, type: '', phone: '+1 112 11245 1212', email: 'sampleemail@sample.com'
    },
    {
      orgId: 5, name: 'Kuppusamy Hospital', address: 'Coimbatore, TamilNadu, India', date: 'B', total: 263, clicked: false, isActive: false,
      admin_count: 20, caregiver_count: 70, patients_count: 120, gateway: 100, type: '', phone: '+1 112 11245 1212', email: 'sampleemail@sample.com'
    },
    {
      orgId: 6, name: 'Ganga Hospital', address: 'Coimbatore, TamilNadu, India', date: 'C', total: 250, clicked: false, isActive: true,
      admin_count: 20, caregiver_count: 40, patients_count: 300, gateway: 10, type: '', phone: '+1 112 11245 1212', email: 'sampleemail@sample.com'
    },
  ];
  clicked = false;
  ngOnInit(): void {
  }

  openSettings(item: number, type: string) {
    this.data[item].clicked = !this.data[item].clicked;
    this.data[item].type = type
  }

  openPage(page: string) {
    this.router.navigate(['/organizationManager/' + page]);
  }

}
