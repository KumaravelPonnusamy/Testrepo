import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-organization-create',
  templateUrl: './organization-create.component.html',
  styleUrls: ['./organization-create.component.css']
})
export class OrganizationCreateComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
