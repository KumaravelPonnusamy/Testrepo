import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-organization-main',
  templateUrl: './organization-main.component.html',
  styleUrls: ['./organization-main.component.css']
})
export class OrganizationMainComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
