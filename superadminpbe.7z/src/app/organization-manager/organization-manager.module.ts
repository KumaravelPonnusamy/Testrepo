import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { OrganizationManagerRoutingModule } from './organization-manager-routing.module';
import { OrganizationMainComponent } from './organization-main/organization-main.component';
import { OrganizationListComponent } from './organization-list/organization-list.component';
import { OrganizationCreateComponent } from './organization-create/organization-create.component';
import { OrganizationEditComponent } from './organization-edit/organization-edit.component';
import { DemoMaterialModule } from 'app/demo-material-module';
import { FlexLayoutModule } from '@angular/flex-layout';
import { SharedModule } from 'app/shared/shared.module';


@NgModule({
  declarations: [OrganizationMainComponent, OrganizationListComponent, OrganizationCreateComponent, OrganizationEditComponent],
  imports: [
    CommonModule,
    DemoMaterialModule,
    FlexLayoutModule,
    SharedModule,
    OrganizationManagerRoutingModule
  ]
})
export class OrganizationManagerModule { }
