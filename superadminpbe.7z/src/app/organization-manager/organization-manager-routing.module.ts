import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { OrganizationCreateComponent } from './organization-create/organization-create.component';
import { OrganizationEditComponent } from './organization-edit/organization-edit.component';
import { OrganizationMainComponent } from './organization-main/organization-main.component';


const routes: Routes = [{
  path: '',
  pathMatch: 'full',
  component: OrganizationMainComponent
},{
  path:'createorg',
  component:OrganizationCreateComponent
},
{
  path:'editorg',
  component:OrganizationEditComponent
}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class OrganizationManagerRoutingModule { }
