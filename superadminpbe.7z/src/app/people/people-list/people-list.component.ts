import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-people-list',
  templateUrl: './people-list.component.html',
  styleUrls: ['./people-list.component.scss']
})
export class PeopleListComponent implements OnInit {

  constructor(private router: Router) { }
  public peopleData = [
    { name: 'Name Second', clicked: false, class: 'online', desgination: 'Nursing Superintendent', hosptital: 'ABS Hospital, Los Angels', phone: '+4495986144214', email: 'support1@abchospital.com', status: 'online' },
    { name: 'Name Second', clicked: false, class: 'online', desgination: 'Nursing Superintendent', hosptital: 'ABS Hospital, Los Angels', phone: '+4495986144215', email: 'support2@abchospital.com', status: 'online' },
    { name: 'Name Second', clicked: false, class: 'busy', desgination: 'Nursing Superintendent', hosptital: 'ABS Hospital, Los Angels', phone: '+4495986144216', email: 'support3@abchospital.com', status: 'online' },
    { name: 'Name Second', clicked: false, class: 'away', desgination: 'Nursing Superintendent', hosptital: 'ABS Hospital, Los Angels', phone: '+4495986144217', email: 'support4@abchospital.com', status: 'online' },
    { name: 'Name Second', clicked: false, class: 'away', desgination: 'Nursing Superintendent', hosptital: 'ABS Hospital, Los Angels', phone: '+44959861442444', email: 'support5@abchospital.com', status: 'online' },
    { name: 'Name Second', clicked: false, class: 'online', desgination: 'Nursing Superintendent', hosptital: 'ABS Hospital, Los Angels', phone: '+44959861442177', email: 'support6@abchospital.com', status: 'online' },
    { name: 'Name Second', clicked: false, class: 'online', desgination: 'Nursing Superintendent', hosptital: 'ABS Hospital, Los Angels', phone: '+4495986144211', email: 'support7@abchospital.com', status: 'online' },
    { name: 'Name Second', clicked: false, class: 'offline', desgination: 'Nursing Superintendent', hosptital: 'ABS Hospital, Los Angels', phone: '+4495986144210', email: 'support8@abchospital.com', status: 'online' },
    { name: 'Name Second', clicked: false, class: 'away', desgination: 'Nursing Superintendent', hosptital: 'ABS Hospital, Los Angels', phone: '+4495986144214', email: 'suppor9t@abchospital.com', status: 'online' },
    { name: 'Name Second', clicked: false, class: 'online', desgination: 'Nursing Superintendent', hosptital: 'ABS Hospital, Los Angels', phone: '+4495986144214', email: 'support10@abchospital.com', status: 'online' },
    { name: 'Name Second', clicked: false, class: 'busy', desgination: 'Nursing Superintendent', hosptital: 'ABS Hospital, Los Angels', phone: '+4495986144214', email: 'support11@abchospital.com', status: 'online' },
    { name: 'Name Second', clicked: false, class: 'online', desgination: 'Nursing Superintendent', hosptital: 'ABS Hospital, Los Angels', phone: '+449598614421401', email: 'support12@abchospital.com', status: 'online' },
    { name: 'Name Second', clicked: false, class: 'offline', desgination: 'Nursing Superintendent', hosptital: 'ABS Hospital, Los Angels', phone: '+449598614421410', email: 'support13@abchospital.com', status: 'online' },
    { name: 'Name Second', clicked: false, class: 'online', desgination: 'Nursing Superintendent', hosptital: 'ABS Hospital, Los Angels', phone: '+44959861442140014', email: 'support14@abchospital.com', status: 'online' },
    { name: 'Name Second', clicked: false, class: 'busy', desgination: 'Nursing Superintendent', hosptital: 'ABS Hospital, Los Angels', phone: '+44959861442114', email: 'support15@abchospital.com', status: 'online' },
    { name: 'Name Second', clicked: false, class: 'offline', desgination: 'Nursing Superintendent', hosptital: 'ABS Hospital, Los Angels', phone: '+44959861442124', email: 'support16@abchospital.com', status: 'online' },
  ]
  ngOnInit(): void {
  }
  openSettings(item: number, type: string) {
    this.peopleData[item].clicked = !this.peopleData[item].clicked;
  }

  openPage(page: string) {
    this.router.navigate(['/people/' + page]);
  }
}
