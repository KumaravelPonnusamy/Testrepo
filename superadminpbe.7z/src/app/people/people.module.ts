import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PeopleComponent } from './people/people.component';
import { PeopleListComponent } from './people-list/people-list.component';
import { PeopleCreateComponent } from './people-create/people-create.component';
import { PeopleRoutingModule } from './people.module.routing';
import { DemoMaterialModule } from 'app/demo-material-module';
import { SharedModule } from 'app/shared/shared.module';
import { FlexLayoutModule } from '@angular/flex-layout';


@NgModule({
  declarations: [PeopleComponent, PeopleListComponent, PeopleCreateComponent],
  imports: [
    CommonModule,
    DemoMaterialModule,
    PeopleRoutingModule,
    SharedModule,
    FlexLayoutModule
  ]
})
export class PeopleModule { }
