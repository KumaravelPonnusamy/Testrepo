import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-people-create',
  templateUrl: './people-create.component.html',
  styleUrls: ['./people-create.component.css']
})
export class PeopleCreateComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
