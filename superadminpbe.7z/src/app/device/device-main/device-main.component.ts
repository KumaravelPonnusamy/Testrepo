import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-device-main',
  templateUrl: './device-main.component.html',
  styleUrls: ['./device-main.component.css']
})
export class DeviceMainComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
