import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DeviceMainComponent } from './device-main/device-main.component';
import { DeviceRoutingModule } from './device.module.routing';
import { DeviceListComponent } from './device-list/device-list.component';
import { DemoMaterialModule } from 'app/demo-material-module';
import { FlexLayoutModule } from '@angular/flex-layout';
import { SharedModule } from 'app/shared/shared.module';


@NgModule({
  declarations: [DeviceMainComponent, DeviceListComponent],
  imports: [
    CommonModule,
    DeviceRoutingModule,
    DemoMaterialModule,
    FlexLayoutModule,
    SharedModule
  ]
})
export class DeviceModule { }
