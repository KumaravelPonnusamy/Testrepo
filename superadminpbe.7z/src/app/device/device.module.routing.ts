import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DeviceMainComponent } from './device-main/device-main.component'
import { 
  AuthGuardService as AuthGuard 
} from './../auth/auth.gaurd.service';
const routes: Routes = [{
  path: '',
  pathMatch: 'full',
  component: DeviceMainComponent,
  canActivate: [AuthGuard] 

}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class DeviceRoutingModule { }
