import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroupDirective, NgForm, Validators } from '@angular/forms';
import { ErrorStateMatcher } from '@angular/material/core';
import { MatSnackBar, MatSnackBarConfig } from '@angular/material';
import { Router } from '@angular/router';

export class MyErrorStateMatcher implements ErrorStateMatcher {
  isErrorState(control: FormControl | null, form: FormGroupDirective | NgForm | null): boolean {
    const isSubmitted = form && form.submitted;
    return !!(control && control.invalid && (control.dirty || control.touched || isSubmitted));
  }
}

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  emailFormControl = new FormControl('', [
    Validators.required,
    Validators.email,
  ]);
  passwordFormControl = new FormControl('', [
    Validators.required,
    Validators.minLength(8),
  ])

  matcher = new MyErrorStateMatcher();
  matcher1 = new MyErrorStateMatcher();
  constructor(public snackBar: MatSnackBar, private router: Router) { }

  ngOnInit(): void {
  }
  
  submit(email: string, password: string) {
    if (email === 'superadmin@pbe.com' && password === 'superadmin') {
      localStorage.setItem('email', email);
      this.router.navigate(['dashboard']);
    } else {
      this.openSnackBar('Email / Password Incorrect', 'Close');
    }
  }
  openSnackBar(message: string, action: string) {
    this.snackBar.open(message, action, {
      duration: 2000,
    });
  }
}
